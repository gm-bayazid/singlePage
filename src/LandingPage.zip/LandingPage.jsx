import React, { useState } from "react";
import "./LandingPage.css";
import thumbnail from "./assets/thumbnail01.png";
import dashboard from "./assets/dashboard.jpg";
import Header from "./header/Header";
import Footer from "./footer/Footer";
import "./header/Header.scss";
import "./footer/Footer.scss";
import ShowcaseStack from "./ShowcaseStack";

export default function LandingPage() {
  const [formStatus, setFormStatus] = useState(null);
  const [showVideo, setShowVideo] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    try {
      const res = await fetch("https://formspree.io/f/your-form-id", {
        method: "POST",
        headers: {
          Accept: "application/json"
        },
        body: form
      });
      const data = await res.json();
      if (data.ok || data.success) {
        setFormStatus("success");
        e.target.reset();
      } else {
        setFormStatus("error");
      }
    } catch (error) {
      setFormStatus("error");
    }
  };

  return (
    <>
      <Header />
      <main className="landing-container">
        {/* Hero Section */}
        <section className="hero">
          <div className="hero-content">
            <div className="hero-text">
              <h1>Simplify Construction Project Monitoring</h1>
              <p>Built by a 17-year veteran PM — say goodbye to chaotic reporting, missed deadlines, and bloated software.</p>
              <div className="hero-buttons">
  <a href="#get-tool" className="btn-shared">Get the Tool & Training</a>
  <a href="#demo" className="btn-shared">Watch a 1-Min Demo</a>
</div>
            </div>
          </div>
          <ShowcaseStack />
        </section>

        {/* Problem Section */}
        <section className="problem">
          <h2>Why Most Project Monitoring Fails</h2>
          <p>Project managers juggle a dozen tasks. Without the right tools, progress slips, budgets inflate, and chaos creeps in.</p>
          <ul className="problem-list">
            <li>❌ Too complex for field teams</li>
            <li>❌ Too expensive for growing firms</li>
            <li>❌ Too rigid for real-world conditions</li>
          </ul>
        </section>

        {/* Features Section */}
        <section id="features" className="features">
          <h2>Key Features</h2>
          <div className="features-grid">
            <div>✅ <strong>Progress Tracker:</strong> Track work status, milestones, and deliverables.</div>
            <div>📊 <strong>Cost Dashboard:</strong> View planned vs. actual spending instantly.</div>
            <div>🧮 <strong>Resource Sheet:</strong> Analyze labor & materials over time.</div>
            <div>📅 <strong>Gantt Chart:</strong> Built-in visual timeline with auto-updates.</div>
            <div>⚠️ <strong>Delay & Risk Log:</strong> Flag issues before they escalate.</div>
            <div>📁 <strong>Auto Reports:</strong> Instantly generate client-ready summaries.</div>
          </div>
        </section>

        {/* See it in Action Section */}
        <section id="action" className="see-action">
          <h2>See it in Action</h2>
          <div className="screenshot">
            <img src={dashboard} alt="Excel Project Monitor dashboard screenshot" />
          </div>
        </section>

        {/* Testimonials */}
        <section id="testimonials" className="testimonials">
          <h2>What Engineers Are Saying</h2>
          <div className="testimonials-grid">
            <div className="testimonial">
              <p>“Before this, weekly reporting took us hours. Now it’s automated and easy to share with clients.”</p>
              <span>— Project Manager, Dhaka-based Contractor</span>
            </div>
            <div className="testimonial">
              <p>“We don’t use Primavera or MS Project, so this tool filled the gap perfectly.”</p>
              <span>— Site Engineer, Chattogram Industrial Project</span>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section id="get-tool" className="cta">
          <h2>Let Excel Do the Work — You Focus on the Build</h2>
          <p>Built by a seasoned PM with 17+ years of field experience. No complex tools. Just a clean, powerful solution that helps you deliver.</p>
          <div className="cta-buttons">
            <a href={require('./assets/PMC_Tools_Demo.zip')} download className="primary-btn">Download Demo Tool</a>
            <button className="primary-btn">Get the Tool</button>
            <button className="primary-btn">Book Free Demo</button>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="contact">
          <h2>Contact or Book a Call</h2>
          <p>Have questions or want a custom demo? Reach out below or book a free strategy session.</p>
          <form onSubmit={handleSubmit} className="contact-form">
            <input name="name" required type="text" placeholder="Your Name" />
            <input name="email" required type="email" placeholder="Your Email" />
            <textarea name="message" required placeholder="Your Message" rows="4"></textarea>
            <button type="submit">Send Message</button>
          </form>
          {formStatus === "success" && <p className="success">Message sent successfully!</p>}
          {formStatus === "error" && <p className="error">Something went wrong. Please try again later.</p>}

          <div className="book-link">
            <a href="https://calendly.com/your-calendly-link" target="_blank" rel="noopener noreferrer">Or book directly via Calendly →</a>
          </div>
        </section>

        {/* WhatsApp FAB */}
        <a href="https://wa.me/8801XXXXXXXXX" target="_blank" rel="noopener noreferrer" className="whatsapp-fab" aria-label="Chat on WhatsApp">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="icon">
            <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12a9.75 9.75 0 1017.708 6.272l2.042.537-.537-2.042A9.75 9.75 0 002.25 12z" />
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9.75a3 3 0 01-3 3m-3 0a3 3 0 013-3" />
          </svg>
        </a>

        {/* Video Modal */}
        {showVideo && (
          <div className="video-modal" onClick={() => setShowVideo(false)}>
            <div className="video-modal-content" onClick={e => e.stopPropagation()}>
              <video controls autoPlay style={{ width: '100%', borderRadius: '12px' }}>
                <source src={require('./assets/Whats Going On Full.mp4')} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
              <button className="close-modal" onClick={() => setShowVideo(false)}>&times;</button>
            </div>
          </div>
        )}
      </main>
      <Footer />
    </>
  );
}
